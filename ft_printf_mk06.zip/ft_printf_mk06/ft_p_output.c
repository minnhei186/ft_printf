/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_p_output.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dhosokaw <dhosokaw@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/23 14:30:19 by dhosokaw          #+#    #+#             */
/*   Updated: 2023/08/29 15:27:46 by dhosokaw         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

int len16(unsigned long long p)
{
	int count;
	count=0;

	while(p!=0)
	{
		p=p/16;
		count++;
	}

	return count;
}

char *make_base16(void)
{
	char *s;
	s=(char *)malloc(sizeof(char)*16);
	int i;
	i=0;
	while(i<10)
	{
		s[i]=i+'0';
		i++;
	}
	while(i<16)
	{
		s[i]=i-10+'a';
		i++;
	}
	return s;
}

	 	

char	*base_16(unsigned long long p)
{
	char	*base_16;
	char	*output;
	int i;
	int len;

	base_16=make_base16();
	len=len16(p)+2;
	output=(char *)malloc(len*sizeof(char)+1);
	if(output==NULL)
		return NULL;

	i=0;
	while (p!=0)
	{
		output[len-1] = base_16[p % 16];
		p = p / 16;
		len--;
		i++;
	}
	output[0] = '0';
	output[1] = 'x';
	output[len+i+1] = '\0';
	return (output);
}

int ft_p_output(va_list *args)
{
	unsigned long long	p;
	char				*str;
	int count ;

	p = (unsigned long long)(va_arg(*args, void *));
	str = base_16(p);
	count=ft_strlen(str);
	ft_putstr(str);
	free(str);
	return count;
}

// int main(void)
// {
// 	int i;
// 	i=123;
// 	int count;
//
// 	count=printf("%p\n",&i);
// 	printf("%i\n",count);
// 	count=ft_printf("%p\n",&i);
// 	printf("%i\n",count);
// 	return 0;
// }