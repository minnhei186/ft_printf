#include "ft_printf.h"

int main(void)
{
	
	//%p test
	int i;
	i=1234;
	ft_printf("%p\n",&i);
	printf("%p\n",&i);


	//%c %s test 
	// ft_printf("%c %s",'h',"hello world");
	// printf("%c %s",'h',"hello world");

	return 0;
}
